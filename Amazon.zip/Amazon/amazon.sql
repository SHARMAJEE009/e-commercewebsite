-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 05, 2024 at 04:55 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `amazon`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `cId` int(11) NOT NULL,
  `cusname` varchar(20) DEFAULT NULL,
  `mobileNo` bigint(20) DEFAULT NULL,
  `emailId` varchar(20) DEFAULT NULL,
  `pid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`cId`, `cusname`, `mobileNo`, `emailId`, `pid`) VALUES
(1, 'Himanshu', 8127740855, 'sharmajee004@gmail.c', 1001),
(2, 'aditya', 9375262673, 'aditya@gmail.com', 1002),
(3, 'prajjwal', 8152638904, 'bjp@gmail.com', 9001),
(4, 'shams', 9382417823, 'shams@gmail.com', 9001),
(5, 'shams', 9382417823, 'shams@gmail.com', 9001),
(6, 'falco', 9728362619, 'folosd@gmail.com', 1003);

-- --------------------------------------------------------

--
-- Table structure for table `customer1`
--

CREATE TABLE `customer1` (
  `cusid` int(11) NOT NULL,
  `cusname` varchar(20) DEFAULT NULL,
  `mobileNum` bigint(20) DEFAULT NULL,
  `emailId` varchar(20) DEFAULT NULL,
  `country` varchar(20) DEFAULT 'INDIA',
  `State` varchar(20) NOT NULL,
  `city` varchar(20) NOT NULL,
  `unm` varchar(20) DEFAULT NULL,
  `pass` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer1`
--

INSERT INTO `customer1` (`cusid`, `cusname`, `mobileNum`, `emailId`, `country`, `State`, `city`, `unm`, `pass`) VALUES
(0, '', 0, '', '', '', '', '', ''),
(101, 'aditya', 7251986246, 'Aditya@gmail.com', 'INDIA', 'UTTAR_PRADESH', 'VARANASI', NULL, NULL),
(102, 'Himanshu', 856986246, 'sharmajee@gmail.com', 'INDIA', '', '', NULL, NULL),
(103, 'prajjwal', 9251986246, 'prjjwal@gmail.com', 'INDIA', '', '', NULL, NULL),
(104, 'deepanshu', 9832745689, 'deep@gmail.com', 'INDIA', 'UP', 'pryagraj', NULL, NULL),
(105, 'MONU', 8832745689, 'MONU@gmail.com', 'INDIA', 'UP', 'Varanasi ', NULL, NULL),
(106, 'chotu', 9932745689, 'chotu@gmail.com', 'INDIA', 'UP', 'Varanasi ', NULL, NULL),
(107, 'Sid', 7862745689, 'sid@gmail.com', 'INDIA', 'UP', 'Varanasi ', NULL, NULL),
(108, 'ishan', 9361245689, 'ishan@gmail.com', 'INDIA', 'UP', 'Varanasi ', NULL, NULL),
(109, 'MONU', 8832745689, 'MONU@gmail.com', 'INDIA', 'UP', 'Varanasi ', NULL, NULL),
(110, 'kushan', 9876545689, 'kushan@gmail.com', 'INDIA', 'BIHAR', 'Mujaffarpur ', NULL, NULL),
(111, 'Amit', 6784945689, 'Amit@gmail.com', 'INDIA', 'BIHAR', 'Mujaffarpur ', NULL, NULL),
(112, 'shaily', 7642587535, 'shaily@gmail.com', 'india', 'UP', 'varanasi', 'shaily_jee', '@shaily'),
(113, 'ekta', 6241567896, 'Ekta@gmail.com', 'india', 'UP', 'varanasi', 'Ekta_', '765'),
(114, 'shuhanshu', 6241567896, 'Ekta@gmail.com', 'india', 'UP', 'varanasi', 'Sudhanshu', 'ertyu'),
(115, 'pooja', 9736482946, 'pooja@gmail.com', 'india', 'MP', 'varanasi', 'poja', '123');

-- --------------------------------------------------------

--
-- Table structure for table `customer3`
--

CREATE TABLE `customer3` (
  `cusId` int(11) NOT NULL,
  `cusName` varchar(20) DEFAULT NULL,
  `mobileNum` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer3`
--

INSERT INTO `customer3` (`cusId`, `cusName`, `mobileNum`) VALUES
(101, 'aditya', 7251986246),
(102, 'Himanshu', 856986246),
(103, 'prajjwal', 9251986246),
(104, 'deepanshu', 9832745689),
(105, 'MONU', 8832745689),
(106, 'chotu', 9932745689),
(107, 'Sid', 7862745689),
(108, 'ishan', 9361245689),
(109, 'MONU', 8832745689),
(110, 'kushan', 9876545689),
(111, 'Amit', 6784945689);

-- --------------------------------------------------------

--
-- Table structure for table `finalbill`
--

CREATE TABLE `finalbill` (
  `billNum` int(11) NOT NULL,
  `orderid` int(11) DEFAULT NULL,
  `cusid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `finalbill`
--

INSERT INTO `finalbill` (`billNum`, `orderid`, `cusid`) VALUES
(111111, 1000, NULL),
(222222, 2000, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `orderid` int(11) NOT NULL,
  `cusid` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `total` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`orderid`, `cusid`, `quantity`, `total`) VALUES
(1000, 101, NULL, NULL),
(2000, 102, NULL, NULL),
(3000, 103, NULL, NULL),
(3001, 115, NULL, 2550);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `pId` int(11) NOT NULL,
  `itemName` varchar(20) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `stockId` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`pId`, `itemName`, `price`, `stockId`) VALUES
(1001, 'Men_shirt', 550, 2),
(1002, 'jens', 1550, 2),
(1003, 'shoes', 2550, 2),
(9001, 'vivoy21', 11000, 1),
(9002, 'oppo21', 30000, 1),
(9003, 'i_phone12', 130000, 1),
(9004, 'one_pluse', 30000, 1),
(9005, 'lava', 2000, 1),
(9006, 'oppo2', 30000, 1);

-- --------------------------------------------------------

--
-- Table structure for table `purchase_product`
--

CREATE TABLE `purchase_product` (
  `purId` int(11) NOT NULL,
  `pId` int(11) DEFAULT NULL,
  `cusid` int(11) DEFAULT NULL,
  `Qty` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `purchase_product`
--

INSERT INTO `purchase_product` (`purId`, `pId`, `cusid`, `Qty`) VALUES
(117, 1003, 101, 2),
(118, 1003, 101, 2),
(119, 9001, 102, 3),
(120, 9001, 102, 3),
(121, 9006, 104, 10),
(122, 1001, 102, 22),
(123, 1001, 101, 3),
(124, 1001, 101, 3),
(125, 9001, 115, 2),
(126, 1001, 115, 4),
(127, 1003, 115, 1),
(128, 1003, 115, 1);

-- --------------------------------------------------------

--
-- Stand-in structure for view `show_cus`
-- (See below for the actual view)
--
CREATE TABLE `show_cus` (
`cusid` int(11)
,`cusname` varchar(20)
,`city` varchar(20)
,`State` varchar(20)
);

-- --------------------------------------------------------

--
-- Table structure for table `stock_category`
--

CREATE TABLE `stock_category` (
  `stockId` int(11) NOT NULL,
  `category_name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `stock_category`
--

INSERT INTO `stock_category` (`stockId`, `category_name`) VALUES
(1, 'Mobie'),
(2, 'clothes'),
(3, 'pan'),
(4, 'shampoo'),
(5, 'TV'),
(6, 'AC');

-- --------------------------------------------------------

--
-- Structure for view `show_cus`
--
DROP TABLE IF EXISTS `show_cus`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `show_cus`  AS SELECT `customer1`.`cusid` AS `cusid`, `customer1`.`cusname` AS `cusname`, `customer1`.`city` AS `city`, `customer1`.`State` AS `State` FROM `customer1` WHERE `customer1`.`city` = 'varanasi' ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`cId`),
  ADD KEY `pid` (`pid`);

--
-- Indexes for table `customer1`
--
ALTER TABLE `customer1`
  ADD PRIMARY KEY (`cusid`);

--
-- Indexes for table `customer3`
--
ALTER TABLE `customer3`
  ADD PRIMARY KEY (`cusId`);

--
-- Indexes for table `finalbill`
--
ALTER TABLE `finalbill`
  ADD PRIMARY KEY (`billNum`),
  ADD KEY `orderid` (`orderid`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`orderid`),
  ADD KEY `cusid` (`cusid`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`pId`),
  ADD KEY `stockId` (`stockId`);

--
-- Indexes for table `purchase_product`
--
ALTER TABLE `purchase_product`
  ADD PRIMARY KEY (`purId`),
  ADD KEY `pId` (`pId`),
  ADD KEY `cusid` (`cusid`);

--
-- Indexes for table `stock_category`
--
ALTER TABLE `stock_category`
  ADD PRIMARY KEY (`stockId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `orderid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3002;

--
-- AUTO_INCREMENT for table `purchase_product`
--
ALTER TABLE `purchase_product`
  MODIFY `purId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=129;

--
-- AUTO_INCREMENT for table `stock_category`
--
ALTER TABLE `stock_category`
  MODIFY `stockId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `customer`
--
ALTER TABLE `customer`
  ADD CONSTRAINT `customer_ibfk_1` FOREIGN KEY (`pid`) REFERENCES `product` (`pId`);

--
-- Constraints for table `finalbill`
--
ALTER TABLE `finalbill`
  ADD CONSTRAINT `finalbill_ibfk_1` FOREIGN KEY (`orderid`) REFERENCES `orders` (`orderid`);

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`cusid`) REFERENCES `customer1` (`cusid`);

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `product_ibfk_1` FOREIGN KEY (`stockId`) REFERENCES `stock_category` (`stockId`);

--
-- Constraints for table `purchase_product`
--
ALTER TABLE `purchase_product`
  ADD CONSTRAINT `purchase_product_ibfk_1` FOREIGN KEY (`pId`) REFERENCES `product` (`pId`),
  ADD CONSTRAINT `purchase_product_ibfk_2` FOREIGN KEY (`cusid`) REFERENCES `customer1` (`cusid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
